"""Admin API Routes"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from typing import List
from datetime import datetime, timedelta

from app.db.database import get_db
from app.db.models import User, Query, AuditLog
from app.api.routes.auth import get_current_user
from app.auth.rbac import Role

router = APIRouter()


class UserList(BaseModel):
    id: int
    email: str
    full_name: str | None
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class QueryStats(BaseModel):
    total_queries: int
    queries_today: int
    avg_confidence: float
    top_departments: List[dict]


class DashboardStats(BaseModel):
    total_users: int
    active_users: int
    total_queries: int
    queries_today: int
    avg_response_time_ms: float


@router.get("/users", response_model=List[UserList])
async def list_users(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Tüm kullanıcıları listele (sadece admin)"""
    if current_user.role != Role.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin yetkisi gerekli")
    
    result = await db.execute(select(User).order_by(User.created_at.desc()))
    users = result.scalars().all()
    return users


@router.get("/stats/dashboard", response_model=DashboardStats)
async def get_dashboard_stats(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Dashboard istatistikleri"""
    if current_user.role not in [Role.ADMIN.value, Role.MANAGER.value]:
        raise HTTPException(status_code=403, detail="Yetersiz yetki")
    
    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Kullanıcı sayıları
    total_users = await db.scalar(select(func.count(User.id)))
    active_users = await db.scalar(
        select(func.count(User.id)).where(User.is_active == True)
    )
    
    # Sorgu sayıları
    total_queries = await db.scalar(select(func.count(Query.id)))
    queries_today = await db.scalar(
        select(func.count(Query.id)).where(Query.created_at >= today)
    )
    
    # Ortalama yanıt süresi
    avg_time = await db.scalar(select(func.avg(Query.processing_time_ms)))
    
    return DashboardStats(
        total_users=total_users or 0,
        active_users=active_users or 0,
        total_queries=total_queries or 0,
        queries_today=queries_today or 0,
        avg_response_time_ms=avg_time or 0,
    )


@router.get("/queries/recent")
async def get_recent_queries(
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Son sorguları getir"""
    if current_user.role not in [Role.ADMIN.value, Role.MANAGER.value]:
        raise HTTPException(status_code=403, detail="Yetersiz yetki")
    
    result = await db.execute(
        select(Query)
        .order_by(Query.created_at.desc())
        .limit(limit)
    )
    queries = result.scalars().all()
    
    return [
        {
            "id": q.id,
            "question": q.question[:100] + "..." if len(q.question) > 100 else q.question,
            "department": q.department,
            "risk_level": q.risk_level,
            "confidence": q.confidence,
            "processing_time_ms": q.processing_time_ms,
            "created_at": q.created_at,
        }
        for q in queries
    ]


@router.patch("/users/{user_id}/role")
async def update_user_role(
    user_id: int,
    role: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Kullanıcı rolünü güncelle (sadece admin)"""
    if current_user.role != Role.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin yetkisi gerekli")
    
    if role not in [r.value for r in Role]:
        raise HTTPException(status_code=400, detail="Geçersiz rol")
    
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    
    user.role = role
    await db.commit()
    
    return {"message": f"Kullanıcı rolü '{role}' olarak güncellendi"}
