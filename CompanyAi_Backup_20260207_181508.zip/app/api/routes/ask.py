"""AI Soru-Cevap API Routes"""

import time
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional

from app.db.database import get_db
from app.db.models import User, Query
from app.api.routes.auth import get_current_user
from app.core.engine import process_question
from app.router.router import decide

router = APIRouter()


class AskRequest(BaseModel):
    question: str
    department: Optional[str] = None  # Opsiyonel departman override


class AskResponse(BaseModel):
    answer: str
    department: str
    mode: str
    risk_level: str
    confidence: float
    processing_time_ms: int


@router.post("/ask", response_model=AskResponse)
async def ask_ai(
    request: AskRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    AI asistana soru sor.
    
    - JWT authentication gerektirir
    - Sorguları veritabanına kaydeder
    """
    start_time = time.time()
    
    try:
        # Soruyu işle
        result = await process_question(request.question, request.department)
        
        processing_time = int((time.time() - start_time) * 1000)
        
        # Sorguyu kaydet
        query = Query(
            user_id=current_user.id,
            question=request.question,
            answer=result["answer"],
            department=result["department"],
            mode=result["mode"],
            risk_level=result["risk"],
            confidence=result["confidence"],
            processing_time_ms=processing_time,
        )
        db.add(query)
        await db.commit()
        
        return AskResponse(
            answer=result["answer"],
            department=result["department"],
            mode=result["mode"],
            risk_level=result["risk"],
            confidence=result["confidence"],
            processing_time_ms=processing_time,
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI işlem hatası: {str(e)}")


@router.get("/health")
async def health_check():
    """Servis sağlık kontrolü"""
    return {"status": "healthy", "service": "Kurumsal AI Asistanı"}


@router.get("/llm/status")
async def llm_status():
    """LLM servis durumu"""
    from app.llm.client import ollama_client
    
    is_available = await ollama_client.is_available()
    models = await ollama_client.get_models() if is_available else []
    
    return {
        "available": is_available,
        "models": models,
        "current_model": ollama_client.model,
    }
