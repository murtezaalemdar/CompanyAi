"""Doküman Yönetimi API Routes - RAG Sistemi"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import List, Optional
import io

from app.db.database import get_db
from app.db.models import User
from app.api.routes.auth import get_current_user

# RAG modülünü güvenli şekilde import et
try:
    from app.rag.vector_store import (
        add_document,
        search_documents,
        get_stats,
        delete_document,
        clear_all_documents,
    )
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False

router = APIRouter()


class DocumentAddRequest(BaseModel):
    content: str
    source: str
    doc_type: str = "text"


class SearchRequest(BaseModel):
    query: str
    n_results: int = 3


class DocumentResponse(BaseModel):
    content: str
    source: str
    relevance: float


@router.get("/status")
async def get_rag_status(current_user: User = Depends(get_current_user)):
    """RAG sistemi durumu"""
    if not RAG_AVAILABLE:
        return {
            "available": False,
            "message": "RAG modülü kurulu değil. chromadb ve sentence-transformers yükleyin."
        }
    
    stats = get_stats()
    return {
        "available": True,
        "document_count": stats.get("document_count", 0),
        "collection": stats.get("collection"),
        "embedding_model": stats.get("embedding_model"),
    }


@router.post("/documents/add")
async def add_document_text(
    request: DocumentAddRequest,
    current_user: User = Depends(get_current_user)
):
    """Metin dokümanı ekle"""
    if not RAG_AVAILABLE:
        raise HTTPException(status_code=503, detail="RAG sistemi kullanılamıyor")
    
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Sadece admin doküman ekleyebilir")
    
    success = add_document(
        content=request.content,
        source=request.source,
        doc_type=request.doc_type
    )
    
    if success:
        return {"message": f"Doküman eklendi: {request.source}", "success": True}
    else:
        raise HTTPException(status_code=500, detail="Doküman eklenemedi")


@router.post("/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """Dosya yükle (PDF, DOCX, TXT)"""
    if not RAG_AVAILABLE:
        raise HTTPException(status_code=503, detail="RAG sistemi kullanılamıyor")
    
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Sadece admin doküman yükleyebilir")
    
    # Dosya tipini kontrol et
    filename = file.filename.lower()
    content = ""
    doc_type = "text"
    
    try:
        file_content = await file.read()
        
        if filename.endswith('.txt'):
            content = file_content.decode('utf-8')
            doc_type = "text"
            
        elif filename.endswith('.pdf'):
            try:
                from PyPDF2 import PdfReader
                pdf = PdfReader(io.BytesIO(file_content))
                content = "\n".join([page.extract_text() or "" for page in pdf.pages])
                doc_type = "pdf"
            except ImportError:
                raise HTTPException(status_code=500, detail="PyPDF2 yüklü değil")
            
        elif filename.endswith('.docx'):
            try:
                from docx import Document
                doc = Document(io.BytesIO(file_content))
                content = "\n".join([para.text for para in doc.paragraphs])
                doc_type = "docx"
            except ImportError:
                raise HTTPException(status_code=500, detail="python-docx yüklü değil")
        
        else:
            raise HTTPException(
                status_code=400, 
                detail="Desteklenmeyen dosya tipi. TXT, PDF veya DOCX yükleyin."
            )
        
        if not content.strip():
            raise HTTPException(status_code=400, detail="Dosya boş veya okunamadı")
        
        # Dokümanı ekle
        success = add_document(
            content=content,
            source=file.filename,
            doc_type=doc_type
        )
        
        if success:
            return {
                "message": f"Dosya yüklendi: {file.filename}",
                "success": True,
                "type": doc_type,
                "chars": len(content)
            }
        else:
            raise HTTPException(status_code=500, detail="Doküman eklenemedi")
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Dosya işleme hatası: {str(e)}")


@router.post("/documents/search", response_model=List[DocumentResponse])
async def search_docs(
    request: SearchRequest,
    current_user: User = Depends(get_current_user)
):
    """Dokümanlarda ara"""
    if not RAG_AVAILABLE:
        raise HTTPException(status_code=503, detail="RAG sistemi kullanılamıyor")
    
    results = search_documents(request.query, n_results=request.n_results)
    
    return [
        DocumentResponse(
            content=doc.get("content", ""),
            source=doc.get("source", ""),
            relevance=doc.get("relevance", 0)
        )
        for doc in results
    ]


@router.delete("/documents/{source}")
async def delete_doc(
    source: str,
    current_user: User = Depends(get_current_user)
):
    """Doküman sil"""
    if not RAG_AVAILABLE:
        raise HTTPException(status_code=503, detail="RAG sistemi kullanılamıyor")
    
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Sadece admin doküman silebilir")
    
    success = delete_document(source)
    
    if success:
        return {"message": f"Doküman silindi: {source}", "success": True}
    else:
        raise HTTPException(status_code=404, detail="Doküman bulunamadı")


@router.delete("/documents")
async def clear_all_docs(
    current_user: User = Depends(get_current_user)
):
    """Tüm dokümanları sil"""
    if not RAG_AVAILABLE:
        raise HTTPException(status_code=503, detail="RAG sistemi kullanılamıyor")
    
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Sadece admin doküman silebilir")
    
    success = clear_all_documents()
    
    if success:
        return {"message": "Tüm dokümanlar silindi", "success": True}
    else:
        raise HTTPException(status_code=500, detail="Silme işlemi başarısız")
