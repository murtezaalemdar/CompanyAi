Laravel Filament benzeri yapı:
- Yönetim özetleri
- Risk panosu
- Departman bazlı KPI