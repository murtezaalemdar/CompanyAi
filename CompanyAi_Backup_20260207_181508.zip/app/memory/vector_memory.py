"""Geliştirilmiş Vektör Hafıza Sistemi"""

from typing import List, Dict, Any
from datetime import datetime
import structlog

logger = structlog.get_logger()

# In-memory storage (Production'da Redis veya PostgreSQL kullanılacak)
_memory: List[Dict[str, Any]] = []


def remember(question: str, answer: str, metadata: Dict[str, Any]) -> None:
    """
    Soru-cevap çiftini hafızaya kaydeder.
    
    Args:
        question: Kullanıcı sorusu
        answer: AI yanıtı
        metadata: Ek bilgiler (departman, risk vb.)
    """
    entry = {
        "q": question,
        "a": answer,
        "meta": metadata,
        "timestamp": datetime.utcnow().isoformat(),
    }
    _memory.append(entry)
    
    # Hafıza boyutunu sınırla (son 1000 kayıt)
    if len(_memory) > 1000:
        _memory.pop(0)
    
    logger.debug("memory_stored", total_entries=len(_memory))


def recall(limit: int = 10) -> List[Dict[str, Any]]:
    """
    Son kayıtları getirir.
    
    Args:
        limit: Maksimum kayıt sayısı
    
    Returns:
        Son N kayıt
    """
    return _memory[-limit:]


def search_memory(query: str, limit: int = 5) -> List[Dict[str, Any]]:
    """
    Basit anahtar kelime araması.
    
    NOT: Production'da vektör benzerlik araması kullanılmalı.
    
    Args:
        query: Arama sorgusu
        limit: Maksimum sonuç sayısı
    
    Returns:
        Eşleşen kayıtlar
    """
    query_lower = query.lower()
    results = []
    
    for entry in reversed(_memory):
        if query_lower in entry["q"].lower() or query_lower in entry["a"].lower():
            results.append(entry)
            if len(results) >= limit:
                break
    
    return results


def get_stats() -> Dict[str, Any]:
    """Hafıza istatistikleri"""
    if not _memory:
        return {"total_entries": 0}
    
    departments = {}
    for entry in _memory:
        dept = entry.get("meta", {}).get("dept", "Bilinmeyen")
        departments[dept] = departments.get(dept, 0) + 1
    
    return {
        "total_entries": len(_memory),
        "by_department": departments,
        "oldest_entry": _memory[0].get("timestamp") if _memory else None,
        "newest_entry": _memory[-1].get("timestamp") if _memory else None,
    }


def clear_memory() -> int:
    """Tüm hafızayı temizler (dikkatli kullanın)"""
    count = len(_memory)
    _memory.clear()
    logger.warning("memory_cleared", cleared_entries=count)
    return count