Sesli saha asistanı:
- STT: Vosk / Whisper local
- TTS: Coqui / Piper
Bu dosya hook noktasıdır.