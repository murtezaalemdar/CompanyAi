import axios from 'axios'

const API_BASE_URL = '/api'

// Axios instance
const api = axios.create({
    baseURL: API_BASE_URL,
    timeout: 300000, // 5 minutes
    headers: {
        'Content-Type': 'application/json',
    },
})

// Request interceptor - add auth token
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token')
    if (token) {
        config.headers.Authorization = `Bearer ${token}`
    }
    return config
})

// Response interceptor - handle 401
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem('token')
            window.location.href = '/login'
        }
        return Promise.reject(error)
    }
)

// Auth API
export const authApi = {
    login: async (email: string, password: string) => {
        const formData = new FormData()
        formData.append('username', email)
        formData.append('password', password)
        const response = await api.post('/auth/login', formData, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        })
        return response.data
    },

    register: async (email: string, password: string, fullName?: string) => {
        const response = await api.post('/auth/register', { email, password, full_name: fullName })
        return response.data
    },

    getMe: async () => {
        const response = await api.get('/auth/me')
        return response.data
    },
}

// AI API
export const aiApi = {
    ask: async (question: string, department?: string) => {
        const response = await api.post('/ask', { question, department })
        return response.data
    },

    askWithFiles: async (question: string, files: File[], department?: string) => {
        const formData = new FormData()
        formData.append('question', question)
        if (department) {
            formData.append('department', department)
        }

        // Append all files
        files.forEach((file, index) => {
            formData.append('files', file)
        })

        const response = await api.post('/ask/multimodal', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        })
        return response.data
    },

    uploadDocument: async (file: File, category?: string) => {
        const formData = new FormData()
        formData.append('file', file)
        if (category) {
            formData.append('category', category)
        }

        const response = await api.post('/rag/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        })
        return response.data
    },

    getHealth: async () => {
        const response = await api.get('/health')
        return response.data
    },

    getLlmStatus: async () => {
        const response = await api.get('/llm/status')
        return response.data
    },
}

// Admin API
export const adminApi = {
    getUsers: async () => {
        const response = await api.get('/admin/users')
        return response.data
    },

    getDashboardStats: async () => {
        const response = await api.get('/admin/stats/dashboard')
        return response.data
    },

    getRecentQueries: async (limit = 20) => {
        const response = await api.get(`/admin/queries/recent?limit=${limit}`)
        return response.data
    },

    updateUserRole: async (userId: number, role: string) => {
        const response = await api.patch(`/admin/users/${userId}/role?role=${role}`)
        return response.data
    },
}

export default api
