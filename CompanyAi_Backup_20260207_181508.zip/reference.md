# 📘 Kurumsal AI Asistanı - Proje Referans Dokümanı

> **Proje Adı:** Kurumsal Yapay Zeka Asistanı – LOCAL & ÖĞRENEN  
> **Amaç:** Kurumsal kullanım için tasarlanmış, tamamen lokal çalışan ve öğrenen bir AI asistan sistemi.

---

## 📂 Proje Yapısı

```
CompanyAi/
├── app/                          # Ana uygulama modülleri
│   ├── api/                      # REST API katmanı
│   │   └── main.py               # FastAPI giriş noktası
│   ├── core/                     # Çekirdek işlem motoru
│   │   └── engine.py             # Merkezi işlem yöneticisi
│   ├── llm/                      # Dil modeli entegrasyonu
│   │   └── local_llm.py          # Lokal LLM bağlantısı
│   ├── memory/                   # Hafıza ve öğrenme sistemi
│   │   └── vector_memory.py      # Vektör tabanlı hafıza
│   ├── router/                   # Akıllı yönlendirme
│   │   └── router.py             # Departman/mod yönlendirici
│   ├── voice/                    # Sesli asistan
│   │   └── field_assistant.py    # Saha asistanı hook noktası
│   └── dashboard/                # Yönetim paneli
│       ├── backend/              # Laravel Filament benzeri yapı
│       └── frontend/             # Admin panel arayüzü
├── docs/                         # Dokümantasyon
│   ├── architecture/             # Mimari şemalar
│   │   └── enterprise_flow.md    # Kurumsal akış şeması
│   └── deployment/               # Deployment rehberleri
│       └── local_setup.md        # Lokal kurulum adımları
└── README.md                     # Proje özeti
```

---

## 🏗️ Mimari Genel Bakış

```mermaid
flowchart LR
    A[Kullanıcı] --> B[API]
    B --> C[Router]
    C --> D[Local LLM]
    D --> E[Vector Hafıza]
    E --> F[Dashboard]
    F --> G[Ses]
```

### Veri Akışı
1. **Kullanıcı** → Soru gönderir
2. **API (`main.py`)** → İsteği alır ve engine'e yönlendirir
3. **Router (`router.py`)** → Departman ve mod belirler
4. **Local LLM (`local_llm.py`)** → Analiz yapar ve cevap üretir
5. **Vector Memory (`vector_memory.py`)** → Soru/cevap çiftini hafızaya alır
6. **Dashboard** → Yönetim özeti ve analizler sunar
7. **Voice** → Sesli saha asistanı entegrasyonu

---

## 📦 Modül Detayları

### 1. API Katmanı (`app/api/main.py`)

**Teknoloji:** FastAPI

**Endpoint'ler:**
| Endpoint | Method | Açıklama |
|----------|--------|----------|
| `/ask` | POST | Soru alma ve işleme |

**Örnek Kullanım:**
```bash
POST /ask
Body: {"question": "Üretim hattında yangın riski var mı?"}
```

---

### 2. Çekirdek Motor (`app/core/engine.py`)

**Fonksiyon:** `handle(question: str)`

**İşleyiş:**
1. Router'dan kontekst alır (`decide`)
2. Local LLM'e soru gönderir (`ask_local_llm`)
3. Cevabı hafızaya kaydeder (`remember`)
4. Sonucu döner

**Bağımlılıklar:**
- `router.router.decide`
- `llm.local_llm.ask_local_llm`
- `memory.vector_memory.remember`

---

### 3. Akıllı Router (`app/router/router.py`)

**Fonksiyon:** `decide(question: str) → dict`

**Yönlendirme Kuralları:**
| Anahtar Kelimeler | Departman | Mod | Risk |
|-------------------|-----------|-----|------|
| "fire", "üretim" | Üretim | Analiz | Orta |
| "nakit", "kâr" | Finans | Yönetim | Orta |
| Diğer | Yönetim | Analiz | Düşük |

**Çıktı Formatı:**
```python
{"dept": "Üretim", "mode": "Analiz", "risk": "Orta"}
```

---

### 4. Local LLM (`app/llm/local_llm.py`)

**Fonksiyon:** `ask_local_llm(question, context) → dict`

**Entegrasyon Noktası:** Ollama / LM Studio

**Çıktı Formatı:**
```python
{
    "department": "Üretim",
    "mode": "Analiz",
    "answer": "[LOCAL LLM] Soru analiz edildi.",
    "risk": "Orta",
    "confidence": 0.86
}
```

> ⚠️ **Not:** Bu modül şu an stub olarak çalışmakta, gerçek LLM entegrasyonu için Ollama/LM Studio bağlantısı yapılmalıdır.

---

### 5. Vektör Hafıza (`app/memory/vector_memory.py`)

**Fonksiyonlar:**
| Fonksiyon | Açıklama |
|-----------|----------|
| `remember(q, a, meta)` | Soru/cevap çiftini hafızaya ekler |
| `recall()` | Son 10 kaydı getirir |

**Veri Yapısı:**
```python
memory = [
    {"q": "soru", "a": "cevap", "meta": {...}},
    ...
]
```

> 💡 **Gelişme Önerisi:** FAISS veya Chroma gibi vektör veritabanı entegrasyonu eklenebilir.

---

### 6. Sesli Saha Asistanı (`app/voice/field_assistant.py`)

**Amaç:** Saha çalışanları için sesli asistan hook noktası

**Planlanan Teknolojiler:**
| Özellik | Teknoloji Seçenekleri |
|---------|----------------------|
| STT (Speech-to-Text) | Vosk, Whisper Local |
| TTS (Text-to-Speech) | Coqui, Piper |

---

### 7. Dashboard (`app/dashboard/`)

#### Backend
**Yapı:** Laravel Filament benzeri
**Özellikler:**
- Yönetim özetleri
- Risk panosu
- Departman bazlı KPI

#### Frontend
**Özellikler:**
- AI karar kayıtları görüntüleme
- Grafik & trend analizi
- Alarm geçmişi

---

## 🚀 Kurulum ve Çalıştırma

### Gereksinimler
- Python 3.8+
- FastAPI
- Ollama veya LM Studio (LLM için)
- (Opsiyonel) FAISS / Chroma (vektör hafıza için)

### Lokal Kurulum
```bash
# Bağımlılıkları yükle
pip install fastapi uvicorn

# API'yi başlat
uvicorn app.api.main:app --reload
```

### LLM Kurulumu
1. [Ollama](https://ollama.ai/) veya [LM Studio](https://lmstudio.ai/) kurulumu
2. İstenilen modeli indirin
3. `local_llm.py` dosyasında entegrasyon yapın

---

## 🔧 Teknoloji Stack'i

| Katman | Teknoloji |
|--------|-----------|
| API Framework | FastAPI |
| LLM | Ollama / LM Studio |
| Vector DB | FAISS / Chroma (planlanıyor) |
| STT | Vosk / Whisper |
| TTS | Coqui / Piper |

---

## 📋 Geliştirme Yol Haritası

- [ ] Gerçek LLM entegrasyonu (Ollama/LM Studio)
- [ ] FAISS/Chroma vektör veritabanı entegrasyonu
- [ ] Sesli asistan tam implementasyonu
- [ ] Dashboard frontend geliştirmesi
- [ ] Authentication ve yetkilendirme
- [ ] Logging ve monitoring

---

## 📝 Önemli Notlar

1. **Offline Çalışma:** Sistem tamamen lokal çalışacak şekilde tasarlanmıştır
2. **Öğrenme:** Her soru/cevap çifti hafızaya alınarak sistem öğrenir
3. **Kurumsal Odak:** Departman bazlı yönlendirme ve risk analizi içerir
4. **Modüler Yapı:** Her bileşen bağımsız olarak geliştirilebilir

---


---

## 🌍 Canlı Sunucu Bilgileri (Deployment)

**Sunucu IP:** `192.168.0.12`  
**Kullanıcı:** `root`  
**Şifre:** `435102`  
**SSH Key:** `keys/companyai_key`

### SSH Bağlantısı
Oluşturulan SSH anahtarı ile bağlanmak için:

```bash
# Anahtar izinlerini ayarla (Linux/Mac)
chmod 600 keys/companyai_key

# Bağlan
ssh -i keys/companyai_key root@192.168.0.12
```

### Anahtarı Sunucuya Kopyalama
```bash
ssh-copy-id -i keys/companyai_key.pub root@192.168.0.12
```

---

## 🛠️ Deployment Geçmişi ve Durum Notları (6 Şubat 2026)

### Yapılan Kritik Düzeltmeler ve Mimari Değişiklikler:
1.  **Docker'dan Native Geçiş:** Performans ve Ollama erişim kolaylığı için Docker container yapısı (Backend/Frontend için) iptal edildi. Backend artık `systemd` servisi olarak, Frontend ise doğrudan `Nginx` üzerinden çalışıyor.
2.  **Hashing Algoritması:** `bcrypt` yerine `pbkdf2_sha256` geçişi tamamlandı.
3.  **Ollama Entegrasyonu:** `OLLAMA_BASE_URL` üzerinden `127.0.0.1:11434` bağlantısı sağlandı. Bağlantı hatalarını debug etmek için `client.py` logları geliştirildi.
4.  **Nginx Yapılandırması:** Port 80 çakışmaları (Docker proxy) giderildi. `/api` ve `/docs` yönlendirmeleri `127.0.0.1:8000`'e çekildi.
5.  **Ortam Değişkenleri:** `.env` dosyası Pydantic validasyon hataları nedeniyle temizlendi, kritik ayarlar doğrudan `systemd` servis dosyasına (`companyai-backend.service`) taşındı.

### Mevcut Durum:
-   **Frontend:** Aktif (Nginx /var/www/html).
-   **Backend:** Aktif (Systemd, Port 8000).
-   **LLM (Ollama):** Mistral aktif, backend erişimi doğrulandı.
-   **Veritabanı:** PostgreSQL hala Docker container (`companyai-db`) içinde çalışıyor.

### Yarım Kalan / Bekleyen İşler:
-   [ ] **DB Entegrasyonu:** Native backend'in Docker içindeki PostgreSQL'e "Authentication Failed" hatası almadan bağlanmasının sağlanması (Şifre senkronizasyonu).
-   [ ] **AI Cevap Kalitesi:** Mistral modelinin kurumsal verilerle test edilmesi.
-   [ ] **Vektör Veritabanı:** Liste tabanlı hafızadan FAISS veya ChromaDB'ye geçiş.
-   [ ] **SSL Kurulumu:** HTTPS (Let's Encrypt) yapılandırması.
-   [ ] **Otomatik Yedekleme:** PostgreSQL backup scripti.
