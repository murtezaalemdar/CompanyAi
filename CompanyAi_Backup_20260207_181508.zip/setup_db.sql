CREATE USER companyai WITH PASSWORD 'your_secure_password';
CREATE DATABASE companyai OWNER companyai;
ALTER USER companyai CREATEDB;
