"""Kurumsal AI Asistanı - Ana Uygulama Paketi"""

__version__ = "2.0.0"
