"""Admin API Routes"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime
import json

from app.db.database import get_db
from app.db.models import User, Query
from app.api.routes.auth import get_current_user
from app.auth.rbac import Role
from app.auth.jwt_handler import hash_password

router = APIRouter()


# Pydantic Schemas

class UserList(BaseModel):
    id: int
    email: str
    full_name: str | None
    department: str | None
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class UserCreateRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str | None = None
    department: str | None = None
    role: str = "user"


class UserUpdateRequest(BaseModel):
    full_name: Optional[str] = None
    department: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None
    password: Optional[str] = None


class QueryStats(BaseModel):
    total_queries: int
    queries_today: int
    avg_confidence: float
    top_departments: List[dict]


class DashboardStats(BaseModel):
    total_users: int
    active_users: int
    total_queries: int
    queries_today: int
    avg_response_time_ms: float


# Routes

@router.get("/users", response_model=List[UserList])
async def list_users(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Tüm kullanıcıları listele (sadece admin)"""
    if current_user.role != Role.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin yetkisi gerekli")
    
    result = await db.execute(select(User).order_by(User.created_at.desc()))
    users = result.scalars().all()
    return users


@router.post("/users", response_model=UserList)
async def create_user(
    user_data: UserCreateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Yeni kullanıcı oluştur (sadece admin)"""
    if current_user.role != Role.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin yetkisi gerekli")
    
    # Email kontrolü
    result = await db.execute(select(User).where(User.email == user_data.email))
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Bu email adresi zaten kullanımda"
        )
    
    # Rol validasyonu
    if user_data.role not in [r.value for r in Role]:
        raise HTTPException(status_code=400, detail="Geçersiz rol")
    
    new_user = User(
        email=user_data.email,
        hashed_password=hash_password(user_data.password),
        full_name=user_data.full_name,
        department=user_data.department,
        role=user_data.role,
        is_active=True
    )
    
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)
    
    return new_user


@router.put("/users/{user_id}", response_model=UserList)
async def update_user(
    user_id: int,
    user_data: UserUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Kullanıcı güncelle (sadece admin)"""
    if current_user.role != Role.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin yetkisi gerekli")
    
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    
    # Alanları güncelle
    if user_data.full_name is not None:
        user.full_name = user_data.full_name
    
    if user_data.department is not None:
        user.department = user_data.department
        
    if user_data.role is not None:
        if user_data.role not in [r.value for r in Role]:
            raise HTTPException(status_code=400, detail="Geçersiz rol")
        user.role = user_data.role
        
    if user_data.is_active is not None:
        user.is_active = user_data.is_active
        
    if user_data.password is not None:
        user.hashed_password = hash_password(user_data.password)
    
    await db.commit()
    await db.refresh(user)
    
    return user


@router.delete("/users/{user_id}")
async def delete_user(
    user_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Kullanıcı sil (sadece admin)"""
    if current_user.role != Role.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin yetkisi gerekli")
    
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Kendinizi silemezsiniz")
    
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    
    await db.delete(user)
    await db.commit()
    
    return {"message": "Kullanıcı başarıyla silindi", "success": True}


@router.get("/stats/dashboard", response_model=DashboardStats)
async def get_dashboard_stats(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Dashboard istatistikleri"""
    if current_user.role not in [Role.ADMIN.value, Role.MANAGER.value]:
        raise HTTPException(status_code=403, detail="Yetersiz yetki")
    
    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Kullanıcı sayıları
    total_users = await db.scalar(select(func.count(User.id)))
    active_users = await db.scalar(
        select(func.count(User.id)).where(User.is_active == True)
    )
    
    # Sorgu sayıları
    total_queries = await db.scalar(select(func.count(Query.id)))
    queries_today = await db.scalar(
        select(func.count(Query.id)).where(Query.created_at >= today)
    )
    
    # Ortalama yanıt süresi
    avg_time = await db.scalar(select(func.avg(Query.processing_time_ms)))
    
    return DashboardStats(
        total_users=total_users or 0,
        active_users=active_users or 0,
        total_queries=total_queries or 0,
        queries_today=queries_today or 0,
        avg_response_time_ms=avg_time or 0,
    )


@router.get("/queries/recent")
async def get_recent_queries(
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Son sorguları getir"""
    if current_user.role not in [Role.ADMIN.value, Role.MANAGER.value, Role.USER.value]:
        raise HTTPException(status_code=403, detail="Yetersiz yetki")
    
    query = select(Query).order_by(Query.created_at.desc())

    # Kısıtlama: Sadece kendi departmanı (User rolü için)
    if current_user.role == Role.USER.value:
        user_depts = []
        if current_user.department:
            try:
                parsed = json.loads(current_user.department)
                if isinstance(parsed, list):
                    user_depts = parsed
                else:
                    user_depts = [current_user.department]
            except json.JSONDecodeError:
                user_depts = [current_user.department]

        if not user_depts:
            return [] # Departmanı yoksa göremez

        # Filtrele: Query departmanı kullanıcının departmanlarından biri olmalı
        query = query.where(Query.department.in_(user_depts))

    result = await db.execute(query.limit(limit))
    queries = result.scalars().all()
    
    return [
        {
            "id": q.id,
            "question": q.question[:100] + "..." if len(q.question) > 100 else q.question,
            "department": q.department,
            "risk_level": q.risk_level,
            "confidence": q.confidence,
            "processing_time_ms": q.processing_time_ms,
            "created_at": q.created_at,
        }
        for q in queries
    ]
