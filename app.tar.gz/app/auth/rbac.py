"""Role-Based Access Control (RBAC)"""

from enum import Enum
from typing import List
from functools import wraps
from fastapi import HTTPException, status


class Role(str, Enum):
    """Kullanıcı rolleri"""
    ADMIN = "admin"
    MANAGER = "manager"
    USER = "user"


# Rol bazlı izinler
PERMISSIONS = {
    Role.ADMIN: ["read", "write", "delete", "admin", "reports", "users", "settings"],
    Role.MANAGER: ["read", "write", "reports", "team"],
    Role.USER: ["read", "ask"],
}


def get_permissions(role: str) -> List[str]:
    """Bir rolün tüm izinlerini döner"""
    try:
        role_enum = Role(role)
        return PERMISSIONS.get(role_enum, [])
    except ValueError:
        return []


def has_permission(role: str, permission: str) -> bool:
    """Kullanıcının belirli bir izne sahip olup olmadığını kontrol eder"""
    permissions = get_permissions(role)
    return permission in permissions


def require_permission(permission: str):
    """
    Endpoint'lere izin kontrolü ekleyen decorator.
    
    Kullanım:
        @router.get("/admin/users")
        @require_permission("users")
        async def get_users(current_user: User = Depends(get_current_user)):
            ...
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # current_user dependency'den gelecek
            current_user = kwargs.get("current_user")
            
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Kimlik doğrulama gerekli"
                )
            
            user_permissions = get_permissions(current_user.role)
            
            if permission not in user_permissions:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Bu işlem için '{permission}' izni gerekli"
                )
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def require_role(required_role: Role):
    """
    Belirli bir rol gerektiren decorator.
    
    Kullanım:
        @router.get("/admin/settings")
        @require_role(Role.ADMIN)
        async def get_settings(current_user: User = Depends(get_current_user)):
            ...
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_user = kwargs.get("current_user")
            
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Kimlik doğrulama gerekli"
                )
            
            # Admin her şeyi yapabilir
            if current_user.role == Role.ADMIN.value:
                return await func(*args, **kwargs)
            
            if current_user.role != required_role.value:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Bu işlem için '{required_role.value}' rolü gerekli"
                )
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator
