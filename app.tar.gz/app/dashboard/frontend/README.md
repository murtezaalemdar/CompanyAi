Admin panel:
- AI karar kayıtları
- Grafik & trend
- Alarm geçmişi