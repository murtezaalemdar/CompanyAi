def ask_local_llm(question, context):
    # Ollama / LM Studio entegrasyonu buraya bağlanır
    return {
        "department": context["dept"],
        "mode": context["mode"],
        "answer": f"[LOCAL LLM] {question} analiz edildi.",
        "risk": context["risk"],
        "confidence": 0.86
    }