# İplik ve Çözgü Hazırlık Standartları - PROFESYONEL REHBER

## 1. İplik Kabul ve Giriş Kalite Kontrol
İplik kalitesi kumaşın %70'ini belirler. Giriş kontrolde şunlara dikkat edilmeli:
- **Uster Değerleri (H, CVm)**: Örme için düşük tüylülük (H), dokuma çözgü için yüksek mukavemet esastır.
- **Numara Kontrolü (Ne/Nm)**: Her partiden en az 5 bobin numara kontrolüne girmeli. Tolerans ±%1.5.
- **Büküm (TPI/TPM)**: 
    - *Örme İpliği:* Düşük büküm (Yumuşak tuşe için). αe (Büküm katsayısı) 3.2 - 3.5 arası.
    - *Dokuma Çözgü:* Yüksek büküm (Mukavemet için). αe 4.0 - 4.5 arası.
- **Yabancı Elyaf (Foreign Matter)**: Polipropilen (PP) kontaminasyonu boyada çıkmaz leke yapar (Kritik).

## 2. Depolama Koşulları (Klimatizasyon)
- **Sıcaklık**: 20-22°C sabit.
- **Bağıl Nem (%RH)**: 
    - Pamuk: %60-65 (Nem aldıkça mukavemet artar).
    - Viskos: %60-65.
    - Polyester: Neme duyarlı değildir ama statik elektrik için %50-55.
- **Kondisyonlama**: İplikler üretime girmeden en az 24 saat işletme ortamında bekletilmeli.

## 3. Bobinleme ve Çözgü (Warping)
- **Cağlık Dizilimi**: Parti (Lot) karışıklığı abraj nedenidir. Asla farklı lotları karıştırma.
- **Gerginlik (Tension)**: Tüm bobinlerde eşit olmalı. Gevşek iplik = Potluk, Gergin iplik = Kopuş.
