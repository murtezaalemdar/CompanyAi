# Yuvarlak ve Düz Örme Üretim Standartları

## 1. Makine Ayarları ve Kalite Parametreleri
- **Fein (Gauge) & İplik İlişkisi**:
    - 20 Fein: Ne 20/1 - 24/1
    - 24 Fein: Ne 24/1 - 30/1
    - 28 Fein: Ne 30/1 - 40/1
    - *Hata*: Yanlış seçim iğne kırığına veya kumaşın "zırh" gibi sert olmasına neden olur.
- **May Dönmesi (Spirality)**:
    - *Nedenleri*: İplik büküm yönünün (S/Z) sistem sayısıyla uyumsuzluğu, yüksek büküm, makine ayarsızlığı.
    - *Çözüm*: Çift kat iplik kullanımı, S/Z karışık dizilim (1S-1Z), Lycra kullanımı.
- **Gramaj (GSM) Ayarı**: Kasnak (Kas) ayarı ve iplik besleme uzunluğu (Loop Length) ile kontrol edilir.

## 2. Yaygın Örme Hataları
- **Biyeli (Barré)**: Yatay çizgiler. Nedenleri: İplik lot farkı, sistemler arası gerginlik farkı, mekik ayarsızlığı.
- **İğne Çizgisi (Needle Line)**: Dikey çizgi. Kırık veya bozuk dilli iğne.
- **Patlak/Delik**: İplik mukavemetsizliği veya yüksek gerginlik. 
- **Yağ Lekesi**: Makine yağlama sisteminin fazlalığı veya iğne yatağı kirliliği.

## 3. Üretim Takip (KPI)
- **Makine Randımanı**: Hedef > %85.
- **Fire Oranı**: Hedef < %2.
- **Devir (RPM)**: Lycra'lı mallarda devir %10-15 düşürülmeli (Isınma ve kopuşu önlemek için).
