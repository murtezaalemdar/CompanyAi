# Dokuma Üretim, Planlama ve Maliyet

## 1. Dokuma Teknolojileri ve Ayarlar
- **Air-Jet**: Yüksek hız, E tipi (Kolay) kumaşlar için. Hava basıncı maliyet kalemidir (Kompresör).
- **Rapier**: Desenli, fantezi ve ağır gramajlı kumaşlar için. Hız düşüktür ama esnektir.
- **Atkı Sıklığı (Picks/cm)**: Kumaş gramajını ve maliyeti direkt etkiler.
- **Çözgü Gerginliği**: Kumaş enine göre Newton cinsinden ayarlanmalı (Örn: 3.5 kN).

## 2. Dokuma Hataları
- **Cımbar İzi**: Kenarlarda delik veya yırtık. Cımbar ayarı veya bilezikleri kontrol edilmeli.
- **Atkı Kaçığı/Yarım Atkı**: Sensör hassasiyeti veya bobin bitimi.
- **Tarak İzi**: Tarak dişlerinde bozukluk veya yanlış tarak numarası seçimi.

## 3. Maliyet Hesaplama (Basit Formül)
- **İplik Maliyeti**: (Çözgü Ağırlığı + Atkı Ağırlığı) x İplik Fiyatı
- **İşçilik**: (Ülke/Bölge Dakika Ücreti) x (Metre Başına Dokuma Süresi)
- **Enerji**: Makine kW x Çalışma Saati + Hava Tüketimi (Airjet için)
- **Genel Gider**: Amortisman, Kira, Yedek Parça payı.
