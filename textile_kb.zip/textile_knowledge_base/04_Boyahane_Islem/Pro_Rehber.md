# Boyahane: Ön İşlem, Boyama, Yıkama ve Baskı

## 1. Ön İşlem (Pre-treatment)
Boyamanın %80'i ön işlemdir. Kötü ön işlem = Kötü Boya (Abraj).
- **Kasar (Bleaching)**: Hidrofiliteyi sağlar. Damla testi < 3 sn olmalı.
- **Yıkama pH**: Pamuk için pH 10.5-11, Yün için 4.5-5.5, Polyester (Yıkama değil ama banyo) 4.5-5.0.
- **Tüy Yakma (Gaze)**: Pürüzsüz yüzey için (Özellikle baskı altı kumaşlarda).

## 2. Boyama Süreçleri
- **Reaktif Boyama (Selülozik)**:
    - *Kritik*: Tuz/Soda dozajlama zamanlaması. Hızlı verilirse boya çöker (Abraj).
    - *Yıkama*: Haslık için sabunlama çok iyi yapılmalı (Hidrolize olmuş boyanın atılması).
- **Dispers Boyama (Polyester)**:
    - *Kritik*: HT (Yüksek Sıcaklık) 130°C. pH 4.5-5.0 sabit kalmalı (Tampon/Buffer kullanımı).
    - *Oligomer*: Soğutma kontrollü yapılmalı yoksa oligomer çökmesi toz yapar.

## 3. Baskı (Rotasyon & Dijital)
- **Kıvam (Pat)**: Düşük vizkozite = Desen yayılır. Yüksek vizkozite = Boya kumaşa işlemez.
- **Şablon (Screen)**: Mesh numarası desen detayına göre seçilmeli (İnce desen = Yüksek Mesh).
- **Fikse**: Buharlı fikse sıcaklığı ve süresi renk verimini (Color Yield) belirler.
