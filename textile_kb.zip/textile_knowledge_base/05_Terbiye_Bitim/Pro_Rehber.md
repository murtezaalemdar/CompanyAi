# Terbiye: Ram, Şardon, Sanfor, Kalite Kontrol

## 1. Ramöz (Stenter) İşlemleri
Tekstil terbiyesinin kalbidir.
- **En ve Gramaj Fiksesi**: İstenen en/gramaj burada ayarlanır. (Çekmezlik için besleme verilmeli).
- **Isı Profili**: 
    - Kurutma Kamaraları: 110-130°C (Nemi uçurur).
    - Fikse Kamaraları: 180-200°C (Polyester molekül yapısını sabitler).
- **Apreler**: Yumuşatıcı, Su itici, Yanmazlık kimyasalları burada fular (Padder) ile verilir.

## 2. Mekanik Bitim İşlemleri
- **Şardon (Raising)**: Tellerle tüy çıkarma. *Dikkat*: Kumaş mukavemetini düşürür. Pasaj sayısı kontrollü olmalı.
- **Sanfor**: Mekanik çekmezlik (Rubber Belt). Yıkama sonrası çekmeyi önler.
- **Traş (Shearing)**: Yüzeydeki tüyleri keserek pürüzsüzlük sağlar.

## 3. Kalite Kontrol (4 Puan Sistemi)
Endüstri standardı. 100 metrekaredeki toplam ceza puanı.
- < 20 Puan: 1. Kalite (A)
- 20-30 Puan: 2. Kalite (B) (Anlaşmaya bağlı)
- > 30 Puan: Iskonto veya Red (C)
