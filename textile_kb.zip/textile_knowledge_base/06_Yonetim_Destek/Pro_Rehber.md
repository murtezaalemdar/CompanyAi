# Pazarlama, İK, Muhasebe, IT (Tekstil Odaklı)

## 1. Pazarlama ve Desen (Design)
- **Kartela**: Müşteriye giden ayna. Renk haslıkları, çekmezlik değerleri kartelada mutlaka test edilmiş olmalı.
- **Termin (Lead Time)**: Lab-dip (3-5 gün) + İplik Temin (7-10 gün) + Üretim (15 gün). Doğru termin verilmezse hava kargo maliyeti çıkar.
- **Varyant**: Ana desenin farklı renk kombinasyonları. Maliyet düşürmek için ortak zemin (ground) kullanılabilir.

## 2. Maliyet ve Muhasebe
- **Birim Maliyet**: (Hammadde + İşçilik + Enerji + Amortisman) / Randıman.
- **Stok Maliyeti**: Tekstilde moda hızlı değişir, ölü stok (Deadstock) riski yüksektir. FIFO (First In First Out) uygulanmalı.

## 3. Bilgi İşlem (IT)
- **Barkod/RFID**: Top takibi için zorunlu. Hangi top hangi makineden çıktı?
- **ERP**: Reçete gizliliği (Boya formülleri) en kritik güvenlik noktasıdır.
- **Yedekleme**: Desen arşivleri (Terabaytlarca veri) en değerli varlıktır.
